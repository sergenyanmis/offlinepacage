import base64
import logging
import os
import re

from fastapi import APIRouter
from lxml import etree
from collections import Counter

from config import settings
from services.qradar_client import QRadarClient
from services.complexity_scorer import score_all_rules_from_export
from services.inactive_rules import get_inactive_rules

router = APIRouter()
logger = logging.getLogger(__name__)

REGEX_TEST_NAMES = {
    "com.q1labs.semsources.cre.tests.PropertyRegex",
    "com.q1labs.semsources.cre.tests.RegexTest",
    "com.q1labs.semsources.cre.tests.EventStringRegex_Test",
    "com.q1labs.semsources.cre.tests.PayloadTest",
    "com.q1labs.semsources.cre.tests.CustomPropertyRegex_Test",
    "com.q1labs.semsources.cre.tests.StringPropertyRegex_Test",
}

ARIEL_REGEX_KEYWORDS = {"IMATCHES", "MATCHES", "ILIKE", "REGEX", "MATCHESREGEX"}


def _resolve_export_path() -> str:
    if os.path.isabs(settings.export_path):
        return settings.export_path
    backend_dir = os.path.dirname(os.path.dirname(__file__))
    project_dir = os.path.dirname(backend_dir)
    candidates = [
        os.path.join(project_dir, settings.export_path),
        os.path.join(backend_dir, settings.export_path),
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    return candidates[0]


def _clean(data: bytes) -> bytes:
    return re.sub(rb"[\x00-\x08\x0b\x0c\x0e-\x1f]", b"", data)


def _decode_rule_data(rule_data_b64: str) -> bytes:
    padded = rule_data_b64 + "=" * (-len(rule_data_b64) % 4)
    return _clean(base64.b64decode(padded))


def _summarize_issues(issues: list) -> list:
    not_tests = Counter()
    repeated = Counter()
    for issue in issues:
        if "NOT kosulu kullanilmis:" in issue:
            test_name = issue.split("NOT kosulu kullanilmis:", 1)[1].strip()
            not_tests[test_name] += 1
        else:
            repeated[issue] += 1
    summarized = []
    if not_tests:
        total = sum(not_tests.values())
        common = ", ".join(f"{name} x{count}" for name, count in not_tests.most_common(3))
        summarized.append(f"{total} defa NOT kosulu kullanilmis" + (f" ({common})" if common else ""))
    for issue, count in repeated.items():
        if count > 1:
            summarized.append(f"{count} defa: {issue}")
        else:
            summarized.append(issue)
    return summarized


def _rule_has_regex(rule_data_b64: str) -> bool:
    if not rule_data_b64:
        return False
    try:
        inner = etree.fromstring(_decode_rule_data(rule_data_b64))
        for test in inner.findall(".//test"):
            tname = test.get("name", "")
            if tname in REGEX_TEST_NAMES:
                return True
            for user_selection in test.findall(".//userSelection"):
                value = (user_selection.text or "").upper()
                if any(keyword in value for keyword in ARIEL_REGEX_KEYWORDS):
                    return True
    except Exception as exc:
        logger.warning("rule_data regex parse failed: %s", exc)
    return False


def _parse_export(export_path: str):
    if not os.path.exists(export_path):
        return []
    try:
        with open(export_path, "rb") as f:
            data = _clean(f.read())
        root = etree.fromstring(data)
        return root.findall("custom_rule")
    except Exception as exc:
        logger.error("export parse failed for %s: %s", export_path, exc)
        return []


def _is_building_block(rule_name: str) -> bool:
    return rule_name.strip().upper().startswith("BB -")


def _is_detection_rule(rule_name: str) -> bool:
    return not _is_building_block(rule_name)


def _issue_source_name(rule_name: str) -> str:
    return rule_name.strip() or "Building Block"


def _rollup_building_block_issues(results):
    building_blocks = [r for r in results if _is_building_block(r.rule_name)]
    rolled_up = []
    for result in results:
        if not _is_detection_rule(result.rule_name):
            continue
        combined_score = result.score
        combined_classification = result.classification
        combined_issues = list(result.breakdown.issues)
        combined_recommendations = list(result.recommendations)
        referenced_blocks = []
        detection_tail = result.rule_name.split(" - ", 2)[-1].strip().lower()
        for bb in building_blocks:
            bb_tail = bb.rule_name.split(" - ", 2)[-1].strip().lower()
            if detection_tail and detection_tail == bb_tail:
                referenced_blocks.append(bb)
        for bb in referenced_blocks:
            if bb.score > combined_score:
                combined_score = bb.score
                combined_classification = bb.classification
            source = _issue_source_name(bb.rule_name)
            for issue in bb.breakdown.issues:
                combined_issues.append(f"{source} icindeki sorun nedeniyle: {issue}")
            for recommendation in bb.recommendations:
                combined_recommendations.append(f"{source} icin oneri: {recommendation}")
        rolled_up.append({
            "id": result.rule_id,
            "name": result.rule_name,
            "score": combined_score,
            "classification": combined_classification,
            "own_score": result.score,
            "own_classification": result.classification,
            "referenced_building_blocks": [
                {"id": bb.rule_id, "name": bb.rule_name, "score": bb.score, "classification": bb.classification}
                for bb in referenced_blocks
            ],
            "breakdown": {
                "condition_count": result.breakdown.condition_count,
                "regex_test_count": result.breakdown.regex_test_count,
                "regex_alternation_count": result.breakdown.regex_alternation_count,
                "regex_wildcard_count": result.breakdown.regex_wildcard_count,
                "regex_catastrophic": result.breakdown.regex_catastrophic,
                "rule_reference_count": result.breakdown.rule_reference_count,
                "reference_set_count": result.breakdown.reference_set_count,
                "ip_list_long": result.breakdown.ip_list_long,
                "ariel_matches": result.breakdown.ariel_matches,
                "negate_count": result.breakdown.negate_count,
                "payload_contains_count": result.breakdown.payload_contains_count,
            },
            "issues": _summarize_issues(combined_issues),
            "recommendations": combined_recommendations,
        })
    return sorted(rolled_up, key=lambda item: item["score"], reverse=True)


@router.get("/api/dashboard/summary")
async def dashboard_summary():
    warnings = []
    client = QRadarClient()

    rules_raw = []
    total = 0
    enabled = 0
    top_expensive = []
    alerts_today = None

    try:
        result = await client.get_all_rules(page=1, page_size=500)
        rules_raw = result.get("rules", [])
        total = result.get("total", len(rules_raw))
        enabled = sum(1 for r in rules_raw if r.get("enabled") is True)
        sorted_by_capacity = sorted(rules_raw, key=lambda r: r.get("average_capacity") or 0, reverse=True)
        top_expensive = [
            {"id": str(r.get("id", "")), "name": r.get("name", ""), "avg_test_time_ms": round((r.get("average_capacity") or 0) / 1_000_000, 2)}
            for r in sorted_by_capacity[:5]
            if (r.get("average_capacity") or 0) > 0
        ]
    except Exception as exc:
        logger.warning("QRadar API summary unavailable: %s", exc)
        warnings.append("QRadar API erisilemedi; API tabanlı metrikler eksik olabilir.")

    try:
        alerts_today = await client.get_sgm_alert_count(hours=24)
    except Exception as exc:
        logger.warning("alert count unavailable: %s", exc)
        warnings.append("Alert sayisi alinamadi.")

    export_path = _resolve_export_path()
    export_rules = _parse_export(export_path)

    if not export_rules:
        warnings.append(f"Export XML bulunamadi veya okunamadi: {export_path}")

    rules_with_regex = sum(1 for rule in export_rules if _rule_has_regex(rule.findtext("rule_data") or ""))

    complexity_results = score_all_rules_from_export(export_path)
    high_complexity_rules = sum(1 for r in complexity_results if r.classification in ("HIGH", "CRITICAL"))

    # 90 gundur tetiklenmeyen kurallar
    inactive_count = None
    try:
        inactive_data = await get_inactive_rules(days=90)
        inactive_count = inactive_data.get("inactive_count", 0)
        if inactive_data.get("warnings"):
            warnings.extend(inactive_data["warnings"])
    except Exception as exc:
        logger.warning("inactive rules unavailable: %s", exc)
        warnings.append("90 gunluk inaktif kural verisi alinamadi.")

    if total == 0 and export_rules:
        total = len(export_rules)

    return {
        "total_rules": total,
        "enabled_rules": enabled,
        "rules_with_regex": rules_with_regex,
        "high_complexity_rules": high_complexity_rules,
        "top_expensive_rules": top_expensive,
        "never_triggered": inactive_count,
        "alerts_today": alerts_today,
        "false_positive_rate_pct": None,
        "data_sources": {
            "qradar_api_rules": bool(rules_raw),
            "export_path": export_path,
            "export_rules": len(export_rules),
        },
        "warnings": warnings,
        "complexity_summary": [
            {
                "id": r.rule_id,
                "name": r.rule_name,
                "score": r.score,
                "classification": r.classification,
                "issues": r.breakdown.issues,
                "recommendations": r.recommendations,
            }
            for r in complexity_results[:10]
        ],
    }


@router.get("/api/dashboard/inactive-rules")
async def inactive_rules_detail():
    """90 gundur tetiklenmeyen SGM kurallarinin detayini dondurur."""
    data = await get_inactive_rules(days=90)
    return data


@router.get("/api/rules/complexity")
async def rules_complexity():
    export_path = _resolve_export_path()
    results = score_all_rules_from_export(export_path)
    rules = _rollup_building_block_issues(results)
    return {
        "export_path": export_path,
        "total": len(rules),
        "classification_legend": [
            {"classification": "LOW",      "range": "0-19",   "description": "Dusuk karmasiklik"},
            {"classification": "MEDIUM",   "range": "20-39",  "description": "Orta karmasiklik"},
            {"classification": "HIGH",     "range": "40-59",  "description": "Yuksek karmasiklik"},
            {"classification": "CRITICAL", "range": "60-100", "description": "Kritik karmasiklik"},
        ],
        "scoring_factors": [
            "Kosul sayisi", "Regex kullanimi", "Regex alternation (|) kullanimi",
            ".* veya .+ wildcard kullanimi", "Catastrophic backtracking riski",
            "Rule reference / Building Block kullanimi", "Reference set yogunlugu",
            "Uzun IP/CIDR listeleri", "Ariel MATCHES/IMATCHES kullanimi",
            "NOT kosullari", "Payload contains kullanimi",
        ],
        "rules": rules,
    }
