import time
import logging
from typing import List, Dict

import httpx

from config import settings

logger = logging.getLogger(__name__)

NINETY_DAYS_SEC = 90 * 24 * 60 * 60


def _headers() -> dict:
    return {
        "SEC": settings.qradar_api_token,
        "Version": "18.0",
        "Accept": "application/json",
    }


def _base_url() -> str:
    return f"https://{settings.qradar_host}:{settings.qradar_port}"


async def get_inactive_rules(days: int = 90) -> Dict:
    """
    Son `days` gun icinde hic tetiklenmemis SGM kurallarini dondurur.
    90days.py mantigini FastAPI servisine entegre eder.
    """
    cutoff = int(time.time() - days * 24 * 60 * 60)
    base = _base_url()
    headers = _headers()

    all_sgm_rules = []
    triggered_names = set()
    warnings = []

    # --- 1. Adim: Aktif USER kurallarini cek ---
    try:
        async with httpx.AsyncClient(verify=settings.qradar_verify_ssl, timeout=60) as client:
            resp = await client.get(
                f"{base}/api/analytics/rules",
                headers=headers,
                params={
                    "fields": "id,name,enabled,origin",
                    "filter": "enabled=true AND origin=\"USER\"",
                    "Range": "items=0-499",
                },
            )
            resp.raise_for_status()
            rules_data = resp.json() if isinstance(resp.json(), list) else []

        all_sgm_rules = sorted(
            {r["name"].strip() for r in rules_data if r.get("name", "").startswith("SGM -")}
        )
    except Exception as exc:
        logger.warning("inactive_rules: kural listesi alinamadi: %s", exc)
        warnings.append(f"Kural listesi alinamadi: {exc}")

    # --- 2. Adim: Son N gunde tetiklenen kurallar (offense description) ---
    try:
        async with httpx.AsyncClient(verify=settings.qradar_verify_ssl, timeout=60) as client:
            resp = await client.get(
                f"{base}/api/siem/offenses",
                headers=headers,
                params={
                    "filter": f"start_time>{cutoff}",
                    "fields": "id,description,start_time",
                    "Range": "items=0-499",
                },
            )
            resp.raise_for_status()
            offenses = resp.json() if isinstance(resp.json(), list) else []

        triggered_names = {
            off["description"].strip()
            for off in offenses
            if off.get("description", "").startswith("SGM -")
        }
    except Exception as exc:
        logger.warning("inactive_rules: offense listesi alinamadi: %s", exc)
        warnings.append(f"Offense listesi alinamadi: {exc}")

    # --- 3. Adim: Tetiklenmemis kurallari hesapla ---
    inactive = sorted(set(all_sgm_rules) - triggered_names)

    return {
        "days": days,
        "cutoff_epoch": cutoff,
        "total_sgm_rules": len(all_sgm_rules),
        "triggered_count": len(triggered_names),
        "inactive_count": len(inactive),
        "inactive_rules": inactive,
        "warnings": warnings,
    }
