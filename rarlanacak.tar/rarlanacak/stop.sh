#!/bin/bash
pkill -f "uvicorn main:app" && echo "Sunucu durduruldu." || echo "Calisan sunucu bulunamadi."
