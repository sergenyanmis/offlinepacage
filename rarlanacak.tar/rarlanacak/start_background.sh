#!/bin/bash
# Arka planda baslatir ve PID kaydeder
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
bash "$SCRIPT_DIR/start.sh" > "$SCRIPT_DIR/server.log" 2>&1 &
echo $! > "$SCRIPT_DIR/server.pid"
echo "Sunucu baslatildi. PID: $(cat $SCRIPT_DIR/server.pid)"
echo "Log: $SCRIPT_DIR/server.log"
echo "Dur: bash $SCRIPT_DIR/stop.sh"
