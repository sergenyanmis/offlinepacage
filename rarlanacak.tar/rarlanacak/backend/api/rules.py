from fastapi import APIRouter, HTTPException, Query
from typing import Optional
from services.qradar_client import QRadarClient
import math

router = APIRouter()


def _capacity_to_score(capacity) -> int:
    """average_capacity (ns) degerini 0-100 arasi karmasiklik skoruna donusturur."""
    if not capacity or capacity <= 0:
        return 0
    ms = capacity / 1_000_000
    # Logaritmik olcek: 10ms~15, 100ms~30, 1000ms~60, 10000ms~90
    score = int(min(100, max(1, 22 * math.log10(max(1, ms)))))
    return score


def _map_rule(raw: dict, group_map: dict = None) -> dict:
    rule_id = str(raw.get("id", ""))
    capacity = raw.get("average_capacity") or 0
    score = _capacity_to_score(capacity)
    return {
        "id": rule_id,
        "name": raw.get("name", ""),
        "enabled": raw.get("enabled", True),
        "group": (group_map or {}).get(rule_id),
        "type": raw.get("type", "EVENT"),
        "owner": raw.get("owner"),
        "origin": raw.get("origin"),
        "average_capacity": capacity,
        "complexity_score": score if capacity > 0 else None,
        "has_regex": False,
        "avg_test_time_ms": round(capacity / 1000000, 2) if capacity else None,
        "trigger_count_24h": None,
        "last_triggered": None,
        "tags": [],
    }


@router.get("/api/rules")
async def list_rules(
    enabled: Optional[bool] = Query(None),
    group: Optional[str] = Query(None),
    min_score: Optional[int] = Query(None),
    has_regex: Optional[bool] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    client = QRadarClient()
    result = await client.get_all_rules(page=page, page_size=page_size, enabled=enabled)
    group_map = await client.build_rule_group_map()

    rules = [_map_rule(r, group_map) for r in result.get("rules", [])]

    # Istemci tarafı filtreler
    if group:
        rules = [r for r in rules if r.get("group") == group]
    if min_score is not None:
        rules = [r for r in rules if (r.get("complexity_score") or 0) >= min_score]
    if has_regex is not None:
        rules = [r for r in rules if r.get("has_regex") == has_regex]

    return {
        "total": result.get("total", len(rules)),
        "page": page,
        "page_size": page_size,
        "rules": rules
    }


@router.get("/api/rules/{rule_id}")
async def get_rule(rule_id: str):
    client = QRadarClient()
    raw = await client.get_rule_detail(rule_id)
    if not raw:
        raise HTTPException(status_code=404, detail="rule_not_found")

    group_map = await client.build_rule_group_map()

    capacity = raw.get("average_capacity") or 0
    score = _capacity_to_score(capacity)

    return {
        **raw,
        "id": str(raw.get("id", rule_id)),
        "group": group_map.get(rule_id),
        "conditions": [],
        "complexity_score": score if capacity > 0 else None,
        "complexity_breakdown": {"capacity_based": True},
        "has_regex": False,
        "avg_test_time_ms": round(capacity / 1000000, 2),
    }


@router.get("/api/rules/{rule_id}/performance")
async def get_rule_performance(
    rule_id: str,
    from_dt: Optional[str] = Query(None, alias="from"),
    to_dt: Optional[str] = Query(None, alias="to"),
    metric: Optional[str] = Query("avg_test_time"),
):
    return {
        "rule_id": rule_id,
        "metric": metric,
        "unit": "ms",
        "points": [],
        "summary": {"min": 0, "max": 0, "avg": 0, "p95": 0}
    }


@router.get("/api/rules/{rule_id}/trends")
async def get_rule_trends(rule_id: str):
    return {
        "rule_id": rule_id,
        "period": "7d",
        "daily_triggers": [],
        "peak_hour": None,
        "top_source_ips": []
    }
