#!/bin/bash
# Offline sunucuda calıstırma scripti
# Gereksinim: Python 3.11

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "======================================================"
echo "  QRadar Rule Analyzer — Baslatiliyor"
echo "======================================================"

# .env kontrolü
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo ""
  echo "  UYARI: .env dosyasini duzenlemeniz gerekiyor!"
  echo "    QRADAR_HOST=<qradar-ip>"
  echo "    QRADAR_API_TOKEN=<sec-token>"
  echo "  Sonra tekrar calistirin: bash start.sh"
  echo "======================================================"
  exit 1
fi

# .env dosyasını backend klasörüne kopyala
cp .env backend/.env

# Python komutunu bul
PYTHON=""
for cmd in python3.11 python3 python; do
  if command -v "$cmd" &>/dev/null; then
    PYTHON="$cmd"
    echo "  Python: $($cmd --version)"
    break
  fi
done

if [ -z "$PYTHON" ]; then
  echo "HATA: Python bulunamadi. Python 3.11 kurun."
  exit 1
fi

# Sanal ortam oluştur (yoksa)
if [ ! -d "venv" ]; then
  echo "  Sanal ortam olusturuluyor..."
  $PYTHON -m venv venv
  if [ $? -ne 0 ]; then
    echo "HATA: venv olusturulamadi."
    exit 1
  fi
fi

# Activate
source venv/bin/activate
echo "  venv aktif: $(which python)"

# Once temel build araclari
echo "  Build araclari kuruluyor..."
pip install \
  --no-index \
  --find-links="$SCRIPT_DIR/wheels" \
  setuptools wheel pip --upgrade --quiet

# Bagimlilikları kur (wheel'lerden, internet gerekmez)
echo "  Bagimliliklar kuruluyor (offline)..."
pip install \
  --no-index \
  --find-links="$SCRIPT_DIR/wheels" \
  -r "$SCRIPT_DIR/backend/requirements.txt"

if [ $? -ne 0 ]; then
  echo ""
  echo "HATA: Paket kurulumu basarisiz."
  echo "  Wheels klasorundeki dosyalar:"
  ls "$SCRIPT_DIR/wheels/"
  exit 1
fi

# Port ayarı
PORT=${APP_PORT:-8000}

echo ""
echo "======================================================"
echo "  Sunucu baslatiliyor..."
echo "  Adres : http://0.0.0.0:$PORT"
echo "  Dur   : Ctrl+C"
echo "======================================================"
echo ""

cd backend
uvicorn main:app \
  --host 0.0.0.0 \
  --port "$PORT" \
  --workers 2 \
  --log-level info
