import re
from models.analysis import RegexIssue

CATASTROPHIC_PATTERNS = [
    (re.compile(r'\([^)]*\+[^)]*\)\+'), "CRITICAL", "catastrophic_backtracking",
     "İç içe quantifier kombinasyonu catastrophic backtracking riski taşır.",
     "Pattern'ı sabit substring içeren OR koşullarına bölün."),
    (re.compile(r'\([^)]*\*[^)]*\)\+'), "CRITICAL", "catastrophic_backtracking",
     "(a*)+ kombinasyonu catastrophic backtracking riski taşır.",
     "Wildcard quantifier'ları azaltın veya pattern'ı yeniden yazın."),
    (re.compile(r'(\.\*){2,}'), "CRITICAL", "catastrophic_backtracking",
     "İç içe .* kullanımı regex motorunu üstel süreye sürükler.",
     "Pattern'ı tek .* veya belirli karakter sınıflarıyla değiştirin."),
]

LOOKAROUND_RE = re.compile(r'\(\?[<!]')
WIDE_WILDCARD_RE = re.compile(r'\.\{[0-9]{3,},')
CASE_INSENSITIVE_RE = re.compile(r'\(\?i\)')


def detect_wide_alternation(pattern: str) -> bool:
    return len(pattern.split('|')) > 5


class RegexDetector:
    def detect(self, conditions: list) -> list[RegexIssue]:
        issues = []
        for condition in conditions:
            operator = getattr(condition, 'operator', '')
            if operator not in ('REGEX', 'MATCHES', 'IMATCHES'):
                continue
            field = getattr(condition, 'field', 'unknown')
            pattern = getattr(condition, 'value', '')
            issues.extend(self._analyze_pattern(field, pattern))
        return issues

    def _analyze_pattern(self, field: str, pattern: str) -> list[RegexIssue]:
        issues = []

        for compiled_re, risk, category, reason, suggestion in CATASTROPHIC_PATTERNS:
            if compiled_re.search(pattern):
                issues.append(RegexIssue(
                    field=field, pattern=pattern,
                    risk=risk, category=category,
                    reason=reason, suggestion=suggestion
                ))

        if detect_wide_alternation(pattern):
            issues.append(RegexIssue(
                field=field, pattern=pattern,
                risk="HIGH", category="wide_alternation",
                reason="5'ten fazla alternation seçeneği var.",
                suggestion="QRadar'ın 'IS ONE OF' operatörünü kullanın — O(1) hash set araması yapar."
            ))

        if LOOKAROUND_RE.search(pattern):
            issues.append(RegexIssue(
                field=field, pattern=pattern,
                risk="HIGH", category="lookaround",
                reason="Negatif lookahead/lookbehind kullanımı tespit edildi.",
                suggestion="İki ayrı kural olarak yazın: biri dahil etme, biri hariç tutma koşuluyla."
            ))

        if WIDE_WILDCARD_RE.search(pattern):
            issues.append(RegexIssue(
                field=field, pattern=pattern,
                risk="MEDIUM", category="wide_wildcard",
                reason=".{100,} gibi geniş wildcard kullanımı.",
                suggestion="Geniş wildcard yerine QID veya log kaynağı filtresi kullanmayı deneyin."
            ))

        if not issues and CASE_INSENSITIVE_RE.search(pattern):
            issues.append(RegexIssue(
                field=field, pattern=pattern,
                risk="LOW", category="case_insensitive",
                reason="(?i) flag hafif ek yük getirir.",
                suggestion="Öncelikle diğer sorunları çözün; bu flag düşük önceliklidir."
            ))

        return issues
