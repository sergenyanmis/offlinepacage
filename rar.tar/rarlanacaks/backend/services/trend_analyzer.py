from statistics import mean
from models.analysis import TrendData
import logging

logger = logging.getLogger(__name__)


def detect_trend(points: list) -> str:
    if len(points) < 3:
        return "INSUFFICIENT_DATA"
    counts = [p.get('count', 0) if isinstance(p, dict) else getattr(p, 'count', 0) for p in points]
    recent_avg = mean(counts[-7:]) if len(counts) >= 7 else mean(counts)
    previous_avg = mean(counts[-14:-7]) if len(counts) >= 14 else mean(counts[:max(1, len(counts) // 2)])
    change_pct = (recent_avg - previous_avg) / (previous_avg + 1) * 100
    if change_pct > 20:
        return "INCREASING"
    elif change_pct < -20:
        return "DECREASING"
    return "STABLE"


class TrendAnalyzer:
    def _empty(self, rule_id: str) -> TrendData:
        return TrendData(
            rule_id=rule_id,
            daily_triggers=[],
            hourly_heatmap=[],
            performance_over_time=[],
            peak_hour=None,
            peak_day=None,
            never_triggered=False,
            top_source_ips=[],
            trend_direction="INSUFFICIENT_DATA"
        )

    async def get_trends(self, rule_id: str, qradar_client=None) -> TrendData:
        if qradar_client is None:
            return self._empty(rule_id)
        try:
            data = await qradar_client.get_trigger_stats(rule_id)
            daily = data.get('daily_triggers', [])
            return TrendData(
                rule_id=rule_id,
                daily_triggers=daily,
                hourly_heatmap=data.get('hourly_heatmap', []),
                performance_over_time=data.get('performance_over_time', []),
                peak_hour=data.get('peak_hour'),
                peak_day=data.get('peak_day'),
                never_triggered=len(daily) == 0 or all(
                    (d.get('count', 0) if isinstance(d, dict) else getattr(d, 'count', 0)) == 0
                    for d in daily
                ),
                top_source_ips=data.get('top_source_ips', []),
                trend_direction=detect_trend(daily)
            )
        except Exception as e:
            logger.error(f"Trend fetch error for rule {rule_id}: {e}")
            return self._empty(rule_id)
