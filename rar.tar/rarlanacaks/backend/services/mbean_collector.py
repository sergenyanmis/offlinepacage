import logging
import glob
import os
from config import settings
from utils.shell_runner import run_local_script, run_via_ssh
from utils.xml_utils import parse_mbean_xml_file

logger = logging.getLogger(__name__)


class MBeanCollector:
    def __init__(self):
        self.jmx_port = settings.mbean_jmx_port
        self.collection_interval = settings.mbean_collection_interval

    async def collect(self, output_dir: str = "/tmp/qradar-analyzer") -> dict[str, dict]:
        if settings.qradar_ssh_key_path and settings.qradar_ssh_host:
            return await self._collect_via_ssh(output_dir)
        return self._collect_local(output_dir)

    def _collect_local(self, output_dir: str) -> dict[str, dict]:
        script = "/opt/qradar/support/expensiverule.sh"
        if not os.path.exists(script):
            logger.warning(f"Script not found: {script}")
            return {}
        try:
            result = run_local_script(script, self.collection_interval, output_dir)
            if result.returncode != 0:
                logger.error(f"expensiverule.sh failed: {result.stderr}")
                return {}
            return self._find_and_parse_latest(output_dir)
        except Exception as e:
            logger.error(f"Local collect error: {e}")
            return {}

    async def _collect_via_ssh(self, output_dir: str) -> dict[str, dict]:
        local_path = f"{output_dir}/latest.tar.gz"
        result = await run_via_ssh(
            host=settings.qradar_ssh_host,
            user=settings.qradar_ssh_user,
            key_path=settings.qradar_ssh_key_path,
            interval=self.collection_interval,
            local_output_path=local_path
        )
        if result:
            from services.performance_parser import PerformanceParser
            parser = PerformanceParser()
            metrics = parser.parse_tar_gz(local_path)
            return {rid: {} for rid in metrics}
        return {}

    def _find_and_parse_latest(self, output_dir: str) -> dict[str, dict]:
        xml_files = glob.glob(f"{output_dir}/**/*.xml", recursive=True)
        if not xml_files:
            return {}
        latest = max(xml_files, key=os.path.getmtime)
        return parse_mbean_xml_file(latest)

    async def check_jmx_reachable(self) -> bool:
        import socket
        try:
            host = settings.qradar_ssh_host or settings.qradar_host
            sock = socket.create_connection((host, self.jmx_port), timeout=5)
            sock.close()
            return True
        except Exception:
            return False
