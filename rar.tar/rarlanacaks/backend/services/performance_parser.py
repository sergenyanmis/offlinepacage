from utils.xml_utils import parse_mbean_xml_file
from models.metrics import PerformanceMetric
from datetime import datetime
import tarfile
import os
import tempfile
import logging

logger = logging.getLogger(__name__)

EXPENSIVE_THRESHOLD_MS = 1.0
CRITICAL_THRESHOLD_MS = 5.0


def classify_performance(avg_test_time_ms: float) -> str:
    if avg_test_time_ms >= CRITICAL_THRESHOLD_MS:
        return "CRITICAL"
    elif avg_test_time_ms >= EXPENSIVE_THRESHOLD_MS:
        return "WARNING"
    return "OK"


def get_field_list(qversion: int, qminorversion: int) -> list[str]:
    base_fields = [
        "AverageResponseTime", "MaximumResponseTime",
        "TotalTestCount", "TotalTestTime", "AverageTestTime",
        "MaximumTestTime", "TotalActionsCount", "TotalActionsTime",
        "AverageActionsTime", "MaximumActionsTime",
        "TotalResponseCount", "TotalResponseTime"
    ]
    if qversion > 750 or (qversion == 750 and qminorversion >= 202162):
        base_fields += [
            "AllTimeMaximumTestTime", "AllTimeMaximumActionsTime",
            "AllTimeMaximumResponseTime", "AllTimeAverageTestTime",
            "AllTimeAverageResponseTime", "AllTimeAverageActionsTime",
            "CapacityEps", "AllTimeCapacityEps"
        ]
    else:
        base_fields += [
            "AverageExecutionTime", "TotalExecutionCount",
            "TotalExecutionTime", "MaximumExecutionTime"
        ]
    return base_fields


class PerformanceParser:
    def parse_metrics(self, raw_metrics: dict) -> dict[str, PerformanceMetric]:
        results = {}
        for rule_id, metrics in raw_metrics.items():
            avg_test = metrics.get("AverageTestTime", 0.0)
            perf = PerformanceMetric(
                rule_id=rule_id,
                avg_test_time_ms=avg_test,
                max_test_time_ms=metrics.get("MaximumTestTime", 0.0),
                avg_response_time_ms=metrics.get("AverageResponseTime", 0.0),
                max_response_time_ms=metrics.get("MaximumResponseTime", 0.0),
                total_test_count=int(metrics.get("TotalTestCount", 0)),
                avg_actions_time_ms=metrics.get("AverageActionsTime", 0.0),
                all_time_max_test_time_ms=metrics.get("AllTimeMaximumTestTime"),
                all_time_avg_test_time_ms=metrics.get("AllTimeAverageTestTime"),
                capacity_eps=metrics.get("CapacityEps"),
                all_time_capacity_eps=metrics.get("AllTimeCapacityEps"),
                performance_class=classify_performance(avg_test),
                collected_at=datetime.utcnow()
            )
            results[rule_id] = perf
        return results

    def parse_tar_gz(self, tar_path: str) -> dict[str, PerformanceMetric]:
        try:
            with tempfile.TemporaryDirectory() as tmpdir:
                with tarfile.open(tar_path, 'r:gz') as tar:
                    tar.extractall(tmpdir)
                for root, _, files in os.walk(tmpdir):
                    for f in files:
                        if f.endswith('.xml'):
                            xml_file = os.path.join(root, f)
                            raw = parse_mbean_xml_file(xml_file)
                            return self.parse_metrics(raw)
        except Exception as e:
            logger.error(f"tar.gz parse error: {e}")
        return {}
