import uuid
import yaml
from datetime import datetime, date
from models.rule import Rule
from models.analysis import AnalysisResult, AnalysisJob, Recommendation
from services.regex_detector import RegexDetector
from services.complexity_scorer import score_all_rules_from_export
from services.performance_parser import PerformanceParser
from services.trend_analyzer import TrendAnalyzer
import logging

logger = logging.getLogger(__name__)

PRIORITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}

_jobs: dict[str, AnalysisJob] = {}


class RuleAnalyzer:
    def __init__(self, qradar_client=None):
        self.qradar_client = qradar_client
        self.regex_detector = RegexDetector()
        self.performance_parser = PerformanceParser()
        self.trend_analyzer = TrendAnalyzer()

    async def analyze_rule(self, rule: Rule, raw_metrics: dict = None) -> AnalysisResult:
        complexity = self.complexity_scorer.score(rule)
        regex_issues = self.regex_detector.detect(rule.conditions)
        trends = await self.trend_analyzer.get_trends(rule.id, self.qradar_client)

        performance = None
        if raw_metrics and rule.id in raw_metrics:
            parsed = self.performance_parser.parse_metrics({rule.id: raw_metrics[rule.id]})
            if rule.id in parsed:
                performance = parsed[rule.id].model_dump()

        recommendations = self._build_recommendations(regex_issues, performance, trends)
        sigma_yaml = self._to_sigma(rule)

        return AnalysisResult(
            rule_id=rule.id,
            rule_name=rule.name,
            complexity=complexity,
            regex_issues=regex_issues,
            performance=performance,
            trends=trends,
            recommendations=recommendations,
            sigma_yaml=sigma_yaml
        )

    def _build_recommendations(self, regex_issues, performance, trends) -> list[Recommendation]:
        recs = []

        for issue in regex_issues:
            if issue.risk in ("CRITICAL", "HIGH"):
                recs.append(Recommendation(
                    priority="HIGH",
                    category="regex",
                    title=f"Riskli regex tespit edildi: {issue.field}",
                    description=issue.reason,
                    action=issue.suggestion
                ))

        if performance:
            avg_ms = performance.get("avg_test_time_ms", 0)
            if avg_ms >= 5.0:
                recs.append(Recommendation(
                    priority="CRITICAL",
                    category="performance",
                    title="Kural 5ms esigini asiyor",
                    description="Bu kural EPS kapasitesini olumsuz etkiliyor olabilir.",
                    action="Kural kosullarini sadelessstirin veya OR zincirlerini ayri kurallara bolun."
                ))

        if trends and trends.never_triggered:
            recs.append(Recommendation(
                priority="MEDIUM",
                category="hygiene",
                title="Kural hic tetiklenmemis",
                description="Bu kural son 90 gun icinde hic tetiklenmemis.",
                action="Kuralın hâlâ geçerli olup olmadığını değerlendirin; gerekirse devre dışı bırakın."
            ))

        return sorted(recs, key=lambda r: PRIORITY_ORDER.get(r.priority, 99))

    def _to_sigma(self, rule: Rule) -> str:
        sigma = {
            "title": rule.name,
            "id": str(uuid.uuid4()),
            "status": "experimental",
            "description": f"QRadar'dan donusturuldu - Rule ID: {rule.id}",
            "author": "QRadar Rule Analyzer",
            "date": date.today().isoformat(),
            "logsource": {"product": "qradar", "service": "siem"},
            "detection": {
                "selection": {c.field: c.value for c in rule.conditions[:5]},
                "condition": "selection"
            },
            "level": "medium",
            "tags": rule.tags or []
        }
        return yaml.dump(sigma, allow_unicode=True, sort_keys=False)


def get_job(job_id: str) -> AnalysisJob | None:
    return _jobs.get(job_id)


def create_job(rule_ids: list[str], interval_seconds: int, output_dir: str) -> AnalysisJob:
    job = AnalysisJob(
        job_id=str(uuid.uuid4())[:8],
        status="running",
        rule_ids=rule_ids,
        interval_seconds=interval_seconds,
        output_dir=output_dir,
        created_at=datetime.utcnow().isoformat(),
    )
    _jobs[job.job_id] = job
    return job


def update_job(job_id: str, **kwargs):
    if job_id in _jobs:
        for k, v in kwargs.items():
            setattr(_jobs[job_id], k, v)
