from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class RuleCondition(BaseModel):
    field: str
    operator: str
    value: str
    is_expensive: bool = False
    regex_complexity: Optional[str] = None


class Rule(BaseModel):
    id: str
    name: str
    enabled: bool = True
    group: Optional[str] = None
    type: str = "EVENT"
    owner: Optional[str] = None
    creation_date: Optional[datetime] = None
    modification_date: Optional[datetime] = None
    conditions: list[RuleCondition] = []
    responses: list[str] = []
    tags: list[str] = []
    complexity_score: Optional[int] = None
    has_regex: bool = False
    avg_test_time_ms: Optional[float] = None
    trigger_count_24h: Optional[int] = None
    last_triggered: Optional[datetime] = None


class RuleGroup(BaseModel):
    id: str
    name: str
    parent_id: Optional[str] = None
    rule_count: int = 0
