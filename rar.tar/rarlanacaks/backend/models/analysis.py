from pydantic import BaseModel
from typing import Optional


class ComplexityScore(BaseModel):
    score: int
    classification: str
    breakdown: dict
    raw_score: int


class RegexIssue(BaseModel):
    field: str
    pattern: str
    risk: str
    category: str
    reason: str
    suggestion: str


class Recommendation(BaseModel):
    priority: str
    category: str
    title: str
    description: str
    action: str


class TrendData(BaseModel):
    rule_id: str
    daily_triggers: list = []
    hourly_heatmap: list = []
    performance_over_time: list = []
    peak_hour: Optional[int] = None
    peak_day: Optional[str] = None
    never_triggered: bool = False
    top_source_ips: list[str] = []
    trend_direction: str = "INSUFFICIENT_DATA"


class AnalysisResult(BaseModel):
    rule_id: str
    rule_name: str
    complexity: Optional[ComplexityScore] = None
    regex_issues: list[RegexIssue] = []
    performance: Optional[dict] = None
    trends: Optional[TrendData] = None
    recommendations: list[Recommendation] = []
    sigma_yaml: Optional[str] = None


class AnalysisJob(BaseModel):
    job_id: str
    status: str = "running"
    rule_ids: list[str] = []
    interval_seconds: int = 0
    output_dir: str = "/tmp/qradar-analyzer"
    created_at: Optional[str] = None
    estimated_completion: Optional[str] = None
    results: Optional[list[AnalysisResult]] = None
    error: Optional[str] = None


class PrerequisiteCheck(BaseModel):
    custom_rule_analysis_enabled: bool = False
    qradar_version: Optional[str] = None
    jmx_reachable: bool = False
    expensiverule_exists: bool = False
