from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class PerformanceMetric(BaseModel):
    rule_id: str
    avg_test_time_ms: float = 0.0
    max_test_time_ms: float = 0.0
    avg_response_time_ms: float = 0.0
    max_response_time_ms: float = 0.0
    total_test_count: int = 0
    avg_actions_time_ms: float = 0.0
    all_time_max_test_time_ms: Optional[float] = None
    all_time_avg_test_time_ms: Optional[float] = None
    capacity_eps: Optional[float] = None
    all_time_capacity_eps: Optional[float] = None
    performance_class: str = "OK"
    collected_at: Optional[datetime] = None


class TrendPoint(BaseModel):
    ts: datetime
    value: float


class DailyPoint(BaseModel):
    date: str
    count: int


class HourlyPoint(BaseModel):
    hour: int
    day_of_week: int
    count: int


class PerfPoint(BaseModel):
    ts: datetime
    avg_ms: float
    max_ms: float
