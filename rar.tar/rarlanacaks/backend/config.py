from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    qradar_host: str = "192.168.1.100"
    qradar_api_token: str = "changeme"
    qradar_port: int = 443
    qradar_verify_ssl: bool = False

    mbean_jmx_port: int = 7799
    mbean_collection_interval: int = 600
    always_on_rule_timing: str = "auto"

    app_port: int = 8000
    app_env: str = "production"
    log_level: str = "INFO"
    cors_origins: str = "http://localhost:3000"

    # Offline QRadar content export XML
    export_path: str = "data/latest_export.xml"

    qradar_ssh_host: Optional[str] = None
    qradar_ssh_user: str = "root"
    qradar_ssh_key_path: Optional[str] = None

    redis_url: Optional[str] = None
    cache_ttl_seconds: int = 300

    class Config:
        env_file = ".env"
        case_sensitive = False

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()

