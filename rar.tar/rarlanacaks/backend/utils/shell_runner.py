import subprocess
import logging
from typing import Optional

logger = logging.getLogger(__name__)


def run_local_script(
    script_path: str,
    interval: int = 0,
    output_dir: str = "/tmp/qradar-analyzer"
) -> subprocess.CompletedProcess:
    cmd = [script_path, "-i", str(interval), "-d", output_dir]
    logger.info(f"Running: {' '.join(cmd)}")
    return subprocess.run(cmd, capture_output=True, text=True, timeout=interval + 120)


async def run_via_ssh(
    host: str,
    user: str,
    key_path: str,
    interval: int = 0,
    remote_output_dir: str = "/tmp/qra",
    local_output_path: str = "/tmp/qradar-analyzer/latest.tar.gz"
) -> Optional[str]:
    try:
        import paramiko
        import os

        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(host, username=user, key_filename=key_path)

        cmd = f"/opt/qradar/support/expensiverule.sh -i {interval} -d {remote_output_dir}"
        _, stdout, stderr = ssh.exec_command(cmd)
        exit_code = stdout.channel.recv_exit_status()

        if exit_code != 0:
            logger.error(f"expensiverule.sh error: {stderr.read().decode()}")
            ssh.close()
            return None

        sftp = ssh.open_sftp()
        try:
            _, stdout2, _ = ssh.exec_command(
                f"ls -t {remote_output_dir}/CustomRule-*.tar.gz | head -1"
            )
            remote_file = stdout2.read().decode().strip()
            if remote_file:
                os.makedirs(os.path.dirname(local_output_path), exist_ok=True)
                sftp.get(remote_file, local_output_path)
        finally:
            sftp.close()
            ssh.close()

        return local_output_path
    except ImportError:
        logger.warning("paramiko kurulu degil, SSH destegi devre disi.")
        return None
    except Exception as e:
        logger.error(f"SSH error: {e}")
        return None
