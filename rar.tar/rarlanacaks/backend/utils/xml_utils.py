import re
import xml.etree.ElementTree as ET


def parse_mbean_xml(xml_content: str) -> dict[str, dict]:
    results = {}
    try:
        root = ET.fromstring(xml_content)
        for bean in root.iter('Bean'):
            name = bean.get('name', '')
            match = re.search(r'Rule_(\d+)', name)
            if not match:
                continue
            rule_id = match.group(1)
            metrics = {}
            for attr in bean.findall('Attribute'):
                attr_name = attr.get('name', '')
                attr_value = attr.get('value', '0')
                try:
                    metrics[attr_name] = float(attr_value)
                except (ValueError, TypeError):
                    metrics[attr_name] = attr_value
            results[rule_id] = metrics
    except ET.ParseError:
        pass
    return results


def parse_mbean_xml_file(xml_path: str) -> dict[str, dict]:
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        results = {}
        for bean in root.iter('Bean'):
            name = bean.get('name', '')
            match = re.search(r'Rule_(\d+)', name)
            if not match:
                continue
            rule_id = match.group(1)
            metrics = {}
            for attr in bean.findall('Attribute'):
                attr_name = attr.get('name', '')
                try:
                    metrics[attr_name] = float(attr.get('value', 0))
                except (ValueError, TypeError):
                    metrics[attr_name] = attr.get('value', '')
            results[rule_id] = metrics
        return results
    except Exception:
        return {}


def parse_tabular_txt(txt_path: str) -> list[dict]:
    rows = []
    try:
        with open(txt_path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()
        if not lines:
            return rows
        headers = lines[0].strip().split('\t')
        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.strip().split('\t')
            row = dict(zip(headers, parts))
            rows.append(row)
    except Exception:
        pass
    return rows
