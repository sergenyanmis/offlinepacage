from fastapi import APIRouter
from services.qradar_client import QRadarClient
from services.mbean_collector import MBeanCollector

router = APIRouter()


@router.get("/api/health")
async def health():
    client = QRadarClient()
    health_data = await client.health_check()
    mbean = MBeanCollector()
    jmx = await mbean.check_jmx_reachable()
    return {
        "status": "ok",
        "qradar_reachable": health_data.get("qradar_reachable", False),
        "jmx_reachable": jmx,
        "version": "1.0.0"
    }
