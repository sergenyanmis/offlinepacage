from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
from services.rule_analyzer import RuleAnalyzer, create_job, get_job, update_job
from services.qradar_client import QRadarClient
from models.rule import Rule, RuleCondition

router = APIRouter()


class AnalyzeRequest(BaseModel):
    interval_seconds: int = 0
    rule_ids: list[str] = []
    output_dir: str = "/tmp/qradar-analyzer"


async def _run_analysis(job_id: str, rule_ids: list[str], output_dir: str):
    client = QRadarClient()
    analyzer = RuleAnalyzer(qradar_client=client)
    results = []

    for rule_id in rule_ids:
        try:
            raw = await client.get_rule_detail(rule_id)
            if raw:
                conditions = [
                    RuleCondition(
                        field=c.get("field", ""),
                        operator=c.get("operator", "IS"),
                        value=str(c.get("value", ""))
                    )
                    for c in raw.get("conditions", [])
                ]
                rule = Rule(
                    id=str(raw.get("id", rule_id)),
                    name=raw.get("name", f"Rule {rule_id}"),
                    enabled=raw.get("enabled", True),
                    conditions=conditions,
                )
            else:
                rule = Rule(id=rule_id, name=f"Rule {rule_id}")
            result = await analyzer.analyze_rule(rule)
            results.append(result)
        except Exception:
            pass

    update_job(job_id, status="completed", results=results)


@router.post("/api/analyze")
async def start_analysis(req: AnalyzeRequest, background_tasks: BackgroundTasks):
    job = create_job(req.rule_ids, req.interval_seconds, req.output_dir)
    if req.rule_ids:
        background_tasks.add_task(_run_analysis, job.job_id, req.rule_ids, req.output_dir)
    else:
        update_job(job.job_id, status="completed", results=[])
    return {
        "job_id": job.job_id,
        "status": job.status,
        "estimated_completion": None
    }


@router.get("/api/analyze/{job_id}")
async def get_analysis_status(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job_not_found")
    return {
        "job_id": job.job_id,
        "status": job.status,
        "results_url": f"/api/analyze/{job_id}/results" if job.status == "completed" else None
    }


@router.get("/api/analyze/{job_id}/results")
async def get_analysis_results(job_id: str):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="job_not_found")
    if job.status != "completed":
        raise HTTPException(status_code=202, detail="analysis_in_progress")
    return {
        "job_id": job_id,
        "status": "completed",
        "results": [r.model_dump() for r in (job.results or [])]
    }
