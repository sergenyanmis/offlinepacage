import base64
import re
from fastapi import APIRouter
from lxml import etree
from services.qradar_client import QRadarClient
from services.complexity_scorer import score_all_rules_from_export

router = APIRouter()

EXPORT_PATH = "/opt/test/qradar-rule-analyzer/offline-package/data/latest_export.xml"

REGEX_TEST_NAMES = {
    "com.q1labs.semsources.cre.tests.PropertyRegex",
    "com.q1labs.semsources.cre.tests.RegexTest",
    "com.q1labs.semsources.cre.tests.EventStringRegex_Test",
    "com.q1labs.semsources.cre.tests.PayloadTest",
    "com.q1labs.semsources.cre.tests.CustomPropertyRegex_Test",
    "com.q1labs.semsources.cre.tests.StringPropertyRegex_Test",
}

ARIEL_REGEX_KEYWORDS = ["IMATCHES", "MATCHES", "ILIKE", "REGEX", "matchesregex"]


def _clean(data: bytes) -> bytes:
    return re.sub(rb'[\x00-\x08\x0b\x0c\x0e-\x1f]', b'', data)


def _rule_has_regex(rule_data_b64: str) -> bool:
    if not rule_data_b64:
        return False
    try:
        raw = _clean(base64.b64decode(rule_data_b64 + "=="))
        inner = etree.fromstring(raw)
        for test in inner.findall(".//test"):
            tname = test.get("name", "")
            if tname in REGEX_TEST_NAMES:
                return True
            for us in test.findall(".//userSelection"):
                val = us.text or ""
                if any(kw in val for kw in ARIEL_REGEX_KEYWORDS):
                    return True
    except Exception:
        pass
    return False


def _parse_export(export_path: str):
    import os
    if not os.path.exists(export_path):
        return []
    with open(export_path, "rb") as f:
        data = _clean(f.read())
    root = etree.fromstring(data)
    return root.findall("custom_rule")


@router.get("/api/dashboard/summary")
async def dashboard_summary():
    client = QRadarClient()

    result = await client.get_all_rules(page=1, page_size=500)
    rules_raw = result.get("rules", [])
    total = result.get("total", len(rules_raw))
    enabled = sum(1 for r in rules_raw if r.get("enabled", True))

    sorted_by_capacity = sorted(
        rules_raw,
        key=lambda r: r.get("average_capacity") or 0,
        reverse=True
    )
    top_expensive = [
        {
            "id": str(r.get("id", "")),
            "name": r.get("name", ""),
            "avg_test_time_ms": round((r.get("average_capacity") or 0) / 1_000_000, 2),
        }
        for r in sorted_by_capacity[:5]
        if (r.get("average_capacity") or 0) > 0
    ]

    export_rules = _parse_export(EXPORT_PATH)

    rules_with_regex = 0
    for r in export_rules:
        b64 = r.findtext("rule_data") or ""
        if _rule_has_regex(b64):
            rules_with_regex += 1

    complexity_results = score_all_rules_from_export(EXPORT_PATH)
    high_complexity_rules = sum(
        1 for cr in complexity_results
        if cr.classification in ("HIGH", "CRITICAL")
    )

    alerts_today = await client.get_sgm_alert_count(hours=24)

    return {
        "total_rules": total,
        "enabled_rules": enabled,
        "rules_with_regex": rules_with_regex,
        "high_complexity_rules": high_complexity_rules,
        "top_expensive_rules": top_expensive,
        "never_triggered": 0,
        "alerts_today": alerts_today,
        "false_positive_rate_pct": 0.0,
        "complexity_summary": [
            {
                "id": cr.rule_id,
                "name": cr.rule_name,
                "score": cr.score,
                "classification": cr.classification,
                "issues": cr.breakdown.issues,
                "recommendations": cr.recommendations,
            }
            for cr in complexity_results[:10]
        ]
    }


@router.get("/api/rules/complexity")
async def rules_complexity():
    results = score_all_rules_from_export(EXPORT_PATH)
    return {
        "rules": [
            {
                "id": cr.rule_id,
                "name": cr.rule_name,
                "score": cr.score,
                "classification": cr.classification,
                "breakdown": {
                    "condition_count": cr.breakdown.condition_count,
                    "regex_test_count": cr.breakdown.regex_test_count,
                    "regex_alternation_count": cr.breakdown.regex_alternation_count,
                    "regex_wildcard_count": cr.breakdown.regex_wildcard_count,
                    "regex_catastrophic": cr.breakdown.regex_catastrophic,
                    "rule_reference_count": cr.breakdown.rule_reference_count,
                    "reference_set_count": cr.breakdown.reference_set_count,
                    "ip_list_long": cr.breakdown.ip_list_long,
                    "ariel_matches": cr.breakdown.ariel_matches,
                    "negate_count": cr.breakdown.negate_count,
                },
                "issues": cr.breakdown.issues,
                "recommendations": cr.recommendations,
            }
            for cr in results
        ]
    }
